﻿using System.Web.UI;

namespace VantageHelpdesk.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}